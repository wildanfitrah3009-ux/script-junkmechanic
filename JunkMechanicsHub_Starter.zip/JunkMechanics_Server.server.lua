-- Junk Mechanics Hub - SERVER
-- Pasang sebagai Script di ServerScriptService.
-- Kontrak model:
--   CollectionService tag "JunkMechanicsVehicle" pada Model kendaraan.
--   CollectionService tag "MechanicalMachine" pada BasePart/Model mesin.
--   Kendaraan memiliki Attribute OwnerUserId (number), EngineWear, BodyWear, WheelWear.
--   Pemain memiliki Attribute Cash (number).
-- Server tetap memvalidasi kepemilikan, jarak, biaya, dan kondisi kendaraan.

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local CollectionService = game:GetService("CollectionService")

local CONFIG = {
    VehicleTag = "JunkMechanicsVehicle",
    MachineTag = "MechanicalMachine",
    MaxDistance = 18,
    RepairCosts = {
        EngineWear = 300,
        BodyWear = 250,
        WheelWear = 500,
    },
    WearThreshold = 0,
}

local folder = ReplicatedStorage:FindFirstChild("JunkMechanicsRemotes")
if not folder then
    folder = Instance.new("Folder")
    folder.Name = "JunkMechanicsRemotes"
    folder.Parent = ReplicatedStorage
end

local repairFunction = folder:FindFirstChild("RepairRequest")
if not repairFunction then
    repairFunction = Instance.new("RemoteFunction")
    repairFunction.Name = "RepairRequest"
    repairFunction.Parent = folder
end

local function getPosition(instance)
    if instance:IsA("BasePart") then
        return instance.Position
    elseif instance:IsA("Model") then
        return instance:GetPivot().Position
    end
    return nil
end

local function getCharacterRoot(player)
    local character = player.Character
    return character and character:FindFirstChild("HumanoidRootPart")
end

local function isNearMachine(player)
    local root = getCharacterRoot(player)
    if not root then return false end

    for _, machine in ipairs(CollectionService:GetTagged(CONFIG.MachineTag)) do
        if machine:IsDescendantOf(workspace) then
            local position = getPosition(machine)
            if position and (root.Position - position).Magnitude <= CONFIG.MaxDistance then
                return true
            end
        end
    end
    return false
end

local function validVehicle(player, vehicle)
    if typeof(vehicle) ~= "Instance" or not vehicle:IsA("Model") then
        return false, "Kendaraan tidak valid."
    end
    if not vehicle:IsDescendantOf(workspace) then
        return false, "Kendaraan tidak ditemukan."
    end
    if not CollectionService:HasTag(vehicle, CONFIG.VehicleTag) then
        return false, "Model bukan kendaraan yang terdaftar."
    end
    if vehicle:GetAttribute("OwnerUserId") ~= player.UserId then
        return false, "Kendaraan bukan milik Anda."
    end

    local root = getCharacterRoot(player)
    local vehiclePosition = getPosition(vehicle)
    if not root or not vehiclePosition then
        return false, "Posisi pemain/kendaraan tidak tersedia."
    end
    if (root.Position - vehiclePosition).Magnitude > CONFIG.MaxDistance then
        return false, "Terlalu jauh dari kendaraan."
    end
    if not isNearMachine(player) then
        return false, "Dekati mesin perbaikan terlebih dahulu."
    end
    return true
end

repairFunction.OnServerInvoke = function(player, vehicle, repairType)
    if repairType ~= "EngineWear" and repairType ~= "BodyWear" and repairType ~= "WheelWear" then
        return false, "Jenis perbaikan tidak dikenal."
    end

    local ok, reason = validVehicle(player, vehicle)
    if not ok then return false, reason end

    local wear = tonumber(vehicle:GetAttribute(repairType)) or 0
    if wear <= CONFIG.WearThreshold then
        return false, "Bagian tersebut tidak memerlukan perbaikan."
    end

    local cost = CONFIG.RepairCosts[repairType]
    local cash = tonumber(player:GetAttribute("Cash")) or 0
    if cash < cost then
        return false, "Uang tidak cukup. Dibutuhkan $" .. cost .. "."
    end

    -- Recheck kondisi sebelum mengubah data.
    player:SetAttribute("Cash", cash - cost)
    vehicle:SetAttribute(repairType, 0)

    return true, repairType .. " berhasil diperbaiki. Biaya: $" .. cost, cost
end

print("[Junk Mechanics Hub] Server repair service ready.")
