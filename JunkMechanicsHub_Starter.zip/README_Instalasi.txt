JUNK MECHANICS HUB - STARTER PACKAGE

PENTING:
Paket ini dibuat untuk game milik tim Anda sendiri. Ini bukan script executor
universal. Client tidak boleh mengubah uang/kondisi kendaraan secara langsung;
semua perubahan dilakukan oleh server melalui RemoteFunction dan validasi.

INSTALASI
1. Di Roblox Studio, buat Script di ServerScriptService.
   Tempel isi JunkMechanics_Server.server.lua.
2. Buat LocalScript di StarterPlayer > StarterPlayerScripts.
   Tempel isi JunkMechanics_Client.client.lua.
3. Beri CollectionService tag "JunkMechanicsVehicle" pada setiap Model kendaraan.
4. Beri tag "MechanicalMachine" pada setiap BasePart atau Model mesin perbaikan.
5. Pada Model kendaraan, set Attributes:
   - OwnerUserId (Number) = UserId pemilik kendaraan
   - EngineWear (Number) = 0..100
   - BodyWear (Number) = 0..100
   - WheelWear (Number) = 0..100
6. Pada Player, set Attribute Cash (Number) saat sistem uang game Anda memuat data.
7. Pastikan karakter perlu berada dekat kendaraan dan mesin. Jarak default 18 studs
   untuk server dan 35 studs untuk pencarian kendaraan di client.

CATATAN INTEGRASI
- Contoh ini menggunakan Attribute sebagai model data generik. Jika game Anda
  menyimpan data kendaraan di ModuleScript/Folder/ValueObject atau sistem lain,
  fungsi validasi dan pembaruan server harus disesuaikan.
- Saat ini "perbaikan" mereset Attribute wear ke 0 dan memotong Cash.
  Animasi, pengambilan part, inventory, dan efek bengkel perlu ditambahkan sesuai
  mekanisme game tim Anda.
- Jangan menaruh logika otoritatif, biaya, atau validasi hanya di LocalScript.
