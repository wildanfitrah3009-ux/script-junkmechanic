-- Junk Mechanics Hub - CLIENT DASHBOARD
-- Untuk game milik tim Anda: pasang sebagai LocalScript di StarterPlayerScripts.
-- Ini bukan script executor universal. ServerScript pendamping wajib dipasang.
-- Kendaraan harus diberi tag "JunkMechanicsVehicle" dan Attribute OwnerUserId,
-- EngineWear, BodyWear, WheelWear. Mesin diberi tag "MechanicalMachine".

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local CollectionService = game:GetService("CollectionService")

local player = Players.LocalPlayer
local remoteFolder = ReplicatedStorage:WaitForChild("JunkMechanicsRemotes")
local repairRequest = remoteFolder:WaitForChild("RepairRequest")

local CONFIG = {
    VehicleTag = "JunkMechanicsVehicle",
    ScanInterval = 3,
    RepairDelay = 1.2,
    MaxVehicleDistance = 35,
}

local enabled = {
    EngineWear = false,
    BodyWear = false,
    WheelWear = false,
    AutoJob = false,
}

local busy = false
local alive = true

local gui = Instance.new("ScreenGui")
gui.Name = "JunkMechanicsHub"
gui.ResetOnSpawn = false
gui.Parent = player:WaitForChild("PlayerGui")

local frame = Instance.new("Frame")
frame.Name = "Main"
frame.Size = UDim2.fromOffset(280, 300)
frame.Position = UDim2.new(0, 24, 0.35, 0)
frame.BackgroundColor3 = Color3.fromRGB(25, 28, 35)
frame.BorderSizePixel = 0
frame.Parent = gui

local corner = Instance.new("UICorner")
corner.CornerRadius = UDim.new(0, 10)
corner.Parent = frame

local title = Instance.new("TextLabel")
title.Size = UDim2.new(1, -44, 0, 38)
title.Position = UDim2.fromOffset(12, 4)
title.BackgroundTransparency = 1
title.Text = "JUNK MECHANICS HUB"
title.TextColor3 = Color3.fromRGB(255, 255, 255)
title.Font = Enum.Font.GothamBold
title.TextSize = 15
title.TextXAlignment = Enum.TextXAlignment.Left
title.Parent = frame

local close = Instance.new("TextButton")
close.Size = UDim2.fromOffset(28, 28)
close.Position = UDim2.new(1, -34, 0, 8)
close.Text = "×"
close.TextSize = 22
close.Font = Enum.Font.GothamBold
close.TextColor3 = Color3.new(1, 1, 1)
close.BackgroundColor3 = Color3.fromRGB(160, 55, 55)
close.Parent = frame
Instance.new("UICorner", close).CornerRadius = UDim.new(0, 7)

local status = Instance.new("TextLabel")
status.Size = UDim2.new(1, -24, 0, 34)
status.Position = UDim2.fromOffset(12, 42)
status.BackgroundColor3 = Color3.fromRGB(38, 43, 53)
status.TextColor3 = Color3.fromRGB(190, 220, 190)
status.Font = Enum.Font.Gotham
status.TextSize = 12
status.Text = "Status: Siap"
status.Parent = frame
Instance.new("UICorner", status).CornerRadius = UDim.new(0, 6)

local function setStatus(message)
    if status.Parent then
        status.Text = "Status: " .. tostring(message)
    end
end

local function makeToggle(label, key, y)
    local button = Instance.new("TextButton")
    button.Size = UDim2.new(1, -24, 0, 34)
    button.Position = UDim2.fromOffset(12, y)
    button.BackgroundColor3 = Color3.fromRGB(65, 70, 82)
    button.TextColor3 = Color3.new(1, 1, 1)
    button.Font = Enum.Font.GothamSemibold
    button.TextSize = 13
    button.Parent = frame
    Instance.new("UICorner", button).CornerRadius = UDim.new(0, 6)

    local function refresh()
        button.Text = label .. ": " .. (enabled[key] and "ON" or "OFF")
        button.BackgroundColor3 = enabled[key]
            and Color3.fromRGB(42, 125, 85)
            or Color3.fromRGB(65, 70, 82)
    end

    button.Activated:Connect(function()
        enabled[key] = not enabled[key]
        refresh()
        setStatus(label .. (enabled[key] and " diaktifkan" or " dimatikan"))
    end)
    refresh()
end

makeToggle("Perbaikan Mesin", "EngineWear", 86)
makeToggle("Perbaikan Bodi", "BodyWear", 126)
makeToggle("Perbaikan Ban/Velg", "WheelWear", 166)
makeToggle("Auto Job", "AutoJob", 206)

local stop = Instance.new("TextButton")
stop.Size = UDim2.new(1, -24, 0, 34)
stop.Position = UDim2.fromOffset(12, 250)
stop.BackgroundColor3 = Color3.fromRGB(155, 65, 65)
stop.Text = "MATIKAN SEMUA"
stop.TextColor3 = Color3.new(1, 1, 1)
stop.Font = Enum.Font.GothamBold
stop.TextSize = 13
stop.Parent = frame
Instance.new("UICorner", stop).CornerRadius = UDim.new(0, 6)

stop.Activated:Connect(function()
    for key in pairs(enabled) do enabled[key] = false end
    for _, child in ipairs(frame:GetChildren()) do
        if child:IsA("TextButton") then
            if child.Text:find("Perbaikan Mesin") then child.Text = "Perbaikan Mesin: OFF" end
            if child.Text:find("Perbaikan Bodi") then child.Text = "Perbaikan Bodi: OFF" end
            if child.Text:find("Perbaikan Ban/Velg") then child.Text = "Perbaikan Ban/Velg: OFF" end
            if child.Text:find("Auto Job") then child.Text = "Auto Job: OFF" end
            if child.Text:find("Perbaikan Mesin") or child.Text:find("Perbaikan Bodi")
                or child.Text:find("Perbaikan Ban/Velg") or child.Text:find("Auto Job") then
                child.BackgroundColor3 = Color3.fromRGB(65, 70, 82)
            end
        end
    end
    setStatus("Semua fitur OFF")
end)

-- Drag dashboard dengan mouse/touch.
do
    local dragging, dragInput, dragStart, startPos
    title.InputBegan:Connect(function(input)
        if input.UserInputType == Enum.UserInputType.MouseButton1
            or input.UserInputType == Enum.UserInputType.Touch then
            dragging = true
            dragStart = input.Position
            startPos = frame.Position
            input.Changed:Connect(function()
                if input.UserInputState == Enum.UserInputState.End then dragging = false end
            end)
        end
    end)
    title.InputChanged:Connect(function(input)
        if input.UserInputType == Enum.UserInputType.MouseMovement
            or input.UserInputType == Enum.UserInputType.Touch then
            dragInput = input
        end
    end)
    game:GetService("UserInputService").InputChanged:Connect(function(input)
        if dragging and input == dragInput then
            local delta = input.Position - dragStart
            frame.Position = UDim2.new(
                startPos.X.Scale, startPos.X.Offset + delta.X,
                startPos.Y.Scale, startPos.Y.Offset + delta.Y
            )
        end
    end)
end

local function findMyVehicle()
    local character = player.Character
    local root = character and character:FindFirstChild("HumanoidRootPart")
    if not root then return nil end

    local nearest, nearestDistance
    for _, vehicle in ipairs(CollectionService:GetTagged(CONFIG.VehicleTag)) do
        if vehicle:IsA("Model") and vehicle:IsDescendantOf(workspace)
            and vehicle:GetAttribute("OwnerUserId") == player.UserId then
            local distance = (vehicle:GetPivot().Position - root.Position).Magnitude
            if distance <= CONFIG.MaxVehicleDistance
                and (not nearestDistance or distance < nearestDistance) then
                nearest, nearestDistance = vehicle, distance
            end
        end
    end
    return nearest
end

local function requestRepair(vehicle, attribute)
    local ok, message = false, "Gagal menghubungi server."
    local success, result, detail = pcall(function()
        return repairRequest:InvokeServer(vehicle, attribute)
    end)
    if success then
        ok, message = result, detail or "Selesai."
    else
        message = tostring(result)
    end
    setStatus(message)
    return ok
end

local function runJob()
    if busy or not alive then return end
    busy = true

    local vehicle = findMyVehicle()
    if not vehicle then
        setStatus("Kendaraan milik Anda tidak ditemukan di dekat pemain.")
        busy = false
        return
    end

    local types = {"EngineWear", "BodyWear", "WheelWear"}
    for _, attribute in ipairs(types) do
        if not alive then break end
        if enabled.AutoJob and enabled[attribute] then
            local wear = tonumber(vehicle:GetAttribute(attribute)) or 0
            if wear > 0 then
                requestRepair(vehicle, attribute)
                task.wait(CONFIG.RepairDelay)
            end
        end
    end

    busy = false
end

task.spawn(function()
    while alive do
        if enabled.AutoJob then
            runJob()
        end
        task.wait(CONFIG.ScanInterval)
    end
end)

close.Activated:Connect(function()
    alive = false
    gui:Destroy()
end)

print("[Junk Mechanics Hub] Dashboard loaded. Configure server tags/attributes first.")
